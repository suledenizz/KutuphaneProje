

package Forms;

import Class.Book;
import Class.Books;
import Class.VeriProje;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class KitapOneri extends javax.swing.JDialog {
 VeriProje mq = new VeriProje();

    public KitapOneri(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        Connect();
        genre();
    }
    Connection con;
    PreparedStatement pst;
    ResultSet rs;

    
    public void Connect(){
     try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
            System.out.println("Veritabanına bağlandı");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmadı...");
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı sağlanmadı");
        }
    }
    
    
        
    /*public class BookItem {

        String name;

        public BookItem(String name) {

            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }*/
    public void genre() {
        try {
            pst = con.prepareStatement("select DISTINCT genre from BOOKSS");
            rs = pst.executeQuery();
            genrecombo.removeAllItems();
            while (rs.next()) {
                genrecombo.addItem(rs.getString(1));
            }

        } catch (SQLException ex) {
            Logger.getLogger(KitapOneri.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
       /* public void comment_load() {
        int c;
        try {

            pst = con.prepareStatement("select b.ID, genre, book_name, co.book_comment FROM BOOKSS b JOIN BOOKCOMMENTS co ON b.ID = co.book_id");
            rs = pst.executeQuery();
            ResultSetMetaData rsd = (ResultSetMetaData) rs.getMetaData();
            c = rsd.getColumnCount();
            DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
            d.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int i = 1; i <= c; i++) {
                    v2.add(rs.getString("ID"));            
                    v2.add(rs.getString("genre"));
                    v2.add(rs.getString("book_name"));
                    v2.add(rs.getString("book_comment"));
                }
                d.addRow(v2);

            }

        } catch (SQLException ex) {
            Logger.getLogger(KitapOneri.class.getName()).log(Level.SEVERE, null, ex);
        }

    }*/


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        geridon = new javax.swing.JButton();
        genrecombo = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(1164, 794));
        jPanel1.setPreferredSize(new java.awt.Dimension(1164, 794));
        jPanel1.setLayout(null);

        geridon.setBackground(new java.awt.Color(168, 194, 206));
        geridon.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        geridon.setForeground(new java.awt.Color(65, 101, 114));
        geridon.setText("Geri Dön");
        geridon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geridonActionPerformed(evt);
            }
        });
        jPanel1.add(geridon);
        geridon.setBounds(470, 590, 200, 40);

        genrecombo.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        genrecombo.setForeground(new java.awt.Color(65, 101, 114));
        genrecombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genrecomboActionPerformed(evt);
            }
        });
        jPanel1.add(genrecombo);
        genrecombo.setBounds(510, 160, 218, 36);

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(65, 101, 114));
        jLabel1.setText("Türü Seçiniz");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(350, 160, 112, 24);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "book_id", "book_name", "writer", "book_page", "genre", "publisher"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(150, 220, 820, 330);

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\ds.png")); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(0, -20, 1100, 830);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1102, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void genrecomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genrecomboActionPerformed
       
   
        ArrayList <Books> list= mq.GetData((String)genrecombo.getSelectedItem());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"id","book_name","writer","book_page","genre","publisher"});
        Object [] row = new Object[6];
        for(int i=0; i<list.size(); i++){
        row[0] = list.get(i).getId();
        row[1] = list.get(i).getBook_name();
        row[2] = list.get(i).getWriter();
        row[3] = list.get(i).getBook_page();
        row[4] = list.get(i).getGenre();
        row[5] = list.get(i).getPublisher();
        model.addRow(row);
        }
        jTable1.setModel(model);
    }//GEN-LAST:event_genrecomboActionPerformed

    private void geridonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geridonActionPerformed
      Anasayfa anasayfa = new Anasayfa();
        anasayfa.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_geridonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KitapOneri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KitapOneri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KitapOneri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KitapOneri.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                KitapOneri dialog = new KitapOneri(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox genrecombo;
    private javax.swing.JButton geridon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
