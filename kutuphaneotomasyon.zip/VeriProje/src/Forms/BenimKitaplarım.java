

package Forms;

import Class.Books;
import Class.MyBooks;
import Class.VeriProje;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class BenimKitaplarım extends javax.swing.JFrame {
 VeriProje vpp = new VeriProje();
    public BenimKitaplarım() {
        initComponents();
        Connect();
        membid();
    }
Connection con;
    PreparedStatement pst;
    ResultSet rs;

    
    public void Connect(){
     try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
            System.out.println("Veritabanına bağlandı");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmadı...");
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı sağlanmadı");
        }
    }
     public void membid() {
        try {
            pst = con.prepareStatement("select DISTINCT ID from USERSS");
            rs = pst.executeQuery();
            idcombobox.removeAllItems();
            while (rs.next()) {
                idcombobox.addItem(rs.getInt(1));
            }

        } catch (SQLException ex) {
            Logger.getLogger(KitapOneri.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        idcombobox = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        geridon = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jTable1.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Üye ID", "Kitap ID", "Kitap Adı"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(240, 200, 720, 360);

        idcombobox.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        idcombobox.setForeground(new java.awt.Color(65, 101, 114));
        idcombobox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idcomboboxActionPerformed(evt);
            }
        });
        jPanel1.add(idcombobox);
        idcombobox.setBounds(590, 130, 220, 40);

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(65, 101, 114));
        jLabel1.setText("ID'nizi Seçiniz");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(390, 130, 150, 24);

        geridon.setBackground(new java.awt.Color(168, 194, 206));
        geridon.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        geridon.setForeground(new java.awt.Color(65, 101, 114));
        geridon.setText("Geri Dön");
        geridon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geridonActionPerformed(evt);
            }
        });
        jPanel1.add(geridon);
        geridon.setBounds(520, 600, 200, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\klj.png")); // NOI18N
        jPanel1.add(jLabel2);
        jLabel2.setBounds(0, 0, 1170, 780);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1167, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 782, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void geridonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geridonActionPerformed
        UyeAnasayfa anasayfa = new UyeAnasayfa(this,true);
        setVisible(false);
        anasayfa.setVisible(true);
        System.exit(0);
    }//GEN-LAST:event_geridonActionPerformed

    private void idcomboboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idcomboboxActionPerformed
        ArrayList <MyBooks> list= vpp.GetDatauser((int)idcombobox.getSelectedItem());
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"memberid","bookid"});
        Object [] row = new Object[2];
        for(int i=0; i<list.size(); i++){
        row[0] = list.get(i).getmemberid();
        row[1] = list.get(i).getbookid();
        model.addRow(row);
        }
        jTable1.setModel(model);
    }//GEN-LAST:event_idcomboboxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BenimKitaplarım.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BenimKitaplarım.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BenimKitaplarım.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BenimKitaplarım.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BenimKitaplarım().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton geridon;
    private javax.swing.JComboBox idcombobox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
