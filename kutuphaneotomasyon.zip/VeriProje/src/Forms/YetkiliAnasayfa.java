
package Forms;

public class YetkiliAnasayfa extends javax.swing.JFrame {

    public YetkiliAnasayfa() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        KitaplarGit = new javax.swing.JButton();
        ÜyelerGit = new javax.swing.JButton();
        Çıkış = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        KitaplarGit.setBackground(new java.awt.Color(168, 194, 206));
        KitaplarGit.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        KitaplarGit.setForeground(new java.awt.Color(65, 101, 114));
        KitaplarGit.setText("Kitaplar");
        KitaplarGit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KitaplarGitActionPerformed(evt);
            }
        });
        jPanel1.add(KitaplarGit);
        KitaplarGit.setBounds(80, 190, 170, 60);

        ÜyelerGit.setBackground(new java.awt.Color(168, 194, 206));
        ÜyelerGit.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        ÜyelerGit.setForeground(new java.awt.Color(65, 101, 114));
        ÜyelerGit.setText("Üyeler");
        ÜyelerGit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ÜyelerGitActionPerformed(evt);
            }
        });
        jPanel1.add(ÜyelerGit);
        ÜyelerGit.setBounds(380, 190, 170, 60);

        Çıkış.setBackground(new java.awt.Color(168, 194, 206));
        Çıkış.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        Çıkış.setForeground(new java.awt.Color(65, 101, 114));
        Çıkış.setText("Çıkış Yap");
        Çıkış.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ÇıkışActionPerformed(evt);
            }
        });
        jPanel1.add(Çıkış);
        Çıkış.setBounds(230, 300, 170, 60);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\yetkiliana.png")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -50, 640, 680);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 625, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void KitaplarGitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KitaplarGitActionPerformed
        Kitaplar kitap = new Kitaplar(this, true);
        setVisible(false);
        kitap.setVisible(true);
        System.exit(0);
    }//GEN-LAST:event_KitaplarGitActionPerformed

    private void ÜyelerGitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ÜyelerGitActionPerformed
       Uyeler uye = new Uyeler(this, true);
       setVisible(false);
       uye.setVisible(true);
       System.exit(0);
    }//GEN-LAST:event_ÜyelerGitActionPerformed

    private void ÇıkışActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ÇıkışActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ÇıkışActionPerformed


    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(YetkiliAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(YetkiliAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(YetkiliAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(YetkiliAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new YetkiliAnasayfa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KitaplarGit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton Çıkış;
    private javax.swing.JButton ÜyelerGit;
    // End of variables declaration//GEN-END:variables
}
