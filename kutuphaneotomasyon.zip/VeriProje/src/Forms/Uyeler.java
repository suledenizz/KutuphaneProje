
package Forms;

import Class.User;
import Class.VeriProje;
import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JFrame;
import javax.swing.JScrollBar;



public class Uyeler extends javax.swing.JDialog {

    DefaultTableModel model2;
    VeriProje vp2 = new VeriProje();
    
    
    public Uyeler(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model2 = (DefaultTableModel)(Users.getModel());
        userView();
        userNumber();
    }

    Uyeler() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void userNumber(){
    count_label.setText("0");
    int ii = vp2.userCount();
    String iii=String.valueOf(ii);
    count_label.setText(iii);}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        name_field = new javax.swing.JTextField();
        surname_field = new javax.swing.JTextField();
        username_field = new javax.swing.JTextField();
        password_field = new javax.swing.JTextField();
        nametext = new javax.swing.JLabel();
        snametext = new javax.swing.JLabel();
        unametext = new javax.swing.JLabel();
        ptext = new javax.swing.JLabel();
        kitapadi1 = new javax.swing.JLabel();
        search = new javax.swing.JLabel();
        Sil = new javax.swing.JButton();
        EkleUye = new javax.swing.JButton();
        Guncelle = new javax.swing.JButton();
        search_field = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Users = new javax.swing.JTable();
        count_label = new javax.swing.JLabel();
        label = new javax.swing.JLabel();
        message5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        name_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        name_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(name_field);
        name_field.setBounds(240, 230, 217, 30);

        surname_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        surname_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(surname_field);
        surname_field.setBounds(240, 280, 217, 30);

        username_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        username_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(username_field);
        username_field.setBounds(240, 340, 217, 30);

        password_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        password_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(password_field);
        password_field.setBounds(240, 390, 217, 30);

        nametext.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        nametext.setForeground(new java.awt.Color(65, 101, 114));
        nametext.setText("Ad");
        jPanel1.add(nametext);
        nametext.setBounds(200, 230, 140, 30);

        snametext.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        snametext.setForeground(new java.awt.Color(65, 101, 114));
        snametext.setText("Soyad");
        jPanel1.add(snametext);
        snametext.setBounds(170, 280, 140, 30);

        unametext.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        unametext.setForeground(new java.awt.Color(65, 101, 114));
        unametext.setText("Kullanıcı Adı");
        jPanel1.add(unametext);
        unametext.setBounds(110, 340, 140, 30);

        ptext.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        ptext.setForeground(new java.awt.Color(65, 101, 114));
        ptext.setText("Şifre");
        jPanel1.add(ptext);
        ptext.setBounds(190, 390, 140, 30);

        kitapadi1.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        kitapadi1.setForeground(new java.awt.Color(65, 101, 114));
        kitapadi1.setText("Üye Ekle");
        jPanel1.add(kitapadi1);
        kitapadi1.setBounds(300, 180, 140, 30);

        search.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        search.setForeground(new java.awt.Color(65, 101, 114));
        search.setText("Arama Yapılacak Kelime");
        jPanel1.add(search);
        search.setBounds(670, 100, 360, 30);

        Sil.setBackground(new java.awt.Color(168, 194, 206));
        Sil.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Sil.setForeground(new java.awt.Color(65, 101, 114));
        Sil.setText("Sil");
        Sil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SilActionPerformed(evt);
            }
        });
        jPanel1.add(Sil);
        Sil.setBounds(830, 460, 160, 40);

        EkleUye.setBackground(new java.awt.Color(168, 194, 206));
        EkleUye.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        EkleUye.setForeground(new java.awt.Color(65, 101, 114));
        EkleUye.setText("Üye Ekle");
        EkleUye.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EkleUyeActionPerformed(evt);
            }
        });
        jPanel1.add(EkleUye);
        EkleUye.setBounds(270, 460, 160, 40);

        Guncelle.setBackground(new java.awt.Color(168, 194, 206));
        Guncelle.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Guncelle.setForeground(new java.awt.Color(65, 101, 114));
        Guncelle.setText("Güncelle");
        Guncelle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuncelleActionPerformed(evt);
            }
        });
        jPanel1.add(Guncelle);
        Guncelle.setBounds(550, 460, 160, 40);

        search_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        search_field.setForeground(new java.awt.Color(65, 101, 114));
        search_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_fieldActionPerformed(evt);
            }
        });
        search_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_fieldKeyReleased(evt);
            }
        });
        jPanel1.add(search_field);
        search_field.setBounds(490, 140, 550, 30);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        Users.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        Users.setForeground(new java.awt.Color(65, 101, 114));
        Users.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "name", "surname", "username", "password"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Users);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(490, 180, 550, 240);

        count_label.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        count_label.setForeground(new java.awt.Color(65, 101, 114));
        count_label.setText("10");
        jPanel1.add(count_label);
        count_label.setBounds(750, 560, 70, 80);

        label.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        label.setForeground(new java.awt.Color(65, 101, 114));
        label.setText("Kütüphanedeki Üye Sayısı");
        jPanel1.add(label);
        label.setBounds(640, 550, 360, 30);

        message5.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        message5.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(message5);
        message5.setBounds(200, 530, 270, 100);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\üye.png")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -40, 1300, 910);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1215, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 832, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void userfilter(String query){
    TableRowSorter <DefaultTableModel> trs = new TableRowSorter <DefaultTableModel>(model2);
    Users.setRowSorter(trs);
    trs.setRowFilter(RowFilter.regexFilter(query));
    
    }
    private void search_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_fieldActionPerformed

    private void search_fieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_fieldKeyReleased
        String query = search_field.getText();
        userfilter(query);
    }//GEN-LAST:event_search_fieldKeyReleased

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked
       int selectedrow = Users.getSelectedRow();
        name_field.setText(model2.getValueAt(selectedrow,1).toString());
        surname_field.setText(model2.getValueAt(selectedrow,2).toString());
        username_field.setText(model2.getValueAt(selectedrow,3).toString());
        password_field.setText(model2.getValueAt(selectedrow,4).toString());
    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void EkleUyeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EkleUyeActionPerformed
 message5.setText("");
        String name = name_field.getText();
        String surname = surname_field.getText();
        String username = username_field.getText();
        String userpassword = password_field.getText();
        if(!(name.isEmpty()||surname.isEmpty()||username.isEmpty()||userpassword.isEmpty())){
        vp2.userAdd(name, surname, username, userpassword);
        userView();
        message5.setText("Üye Eklendi");
        }
        else{
        message5.setText("Üye Eklenemedi!");
        }
    }//GEN-LAST:event_EkleUyeActionPerformed

    private void GuncelleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuncelleActionPerformed
        String name = name_field.getText();
        String surname = surname_field.getText();
        String username = username_field.getText();
        String password = password_field.getText();
        
        int selectedrow = Users.getSelectedRow();
        
        if(selectedrow == -1){
            if(model2.getRowCount()==0){
                message5.setText("");
            }
            else{
                message5.setText("Güncellenecek Üye Seçiniz");
            }
        }
        else{
        int id =(int) model2.getValueAt(selectedrow, 0);
        vp2.userUpdate(id,name,surname,username,password);
        userView();
        message5.setText("Üye Bilgileri Güncellendi");
        }
    }//GEN-LAST:event_GuncelleActionPerformed

    private void SilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SilActionPerformed
         message5.setText("");
        int selectedrow = Users.getSelectedRow();
        
        if(selectedrow == -1){
            if(model2.getRowCount()==0){
                message5.setText("");
            }
            else{
                message5.setText("Silinecek Üyeyi Seçiniz");
            }
        }
        else{
        int id =(int) model2.getValueAt(selectedrow, 0);
        vp2.userDelete(id);
        userView();
        message5.setText("Üye Silindi");
        }
    }//GEN-LAST:event_SilActionPerformed

    
     public void userView(){
        
        model2.setRowCount(0); //her açılışta güncelleyip getirecek
        ArrayList<User> users = new ArrayList<User> ();
        users = vp2.UserCome();
        if(users!=null){
            for(User u : users){
                Object [] add = {u.getId(), u.getName(),u.getSurname(),u.getUsername(),u.getUserpassword()};
                model2.addRow(add);
            }
            
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Uyeler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Uyeler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Uyeler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Uyeler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Uyeler dialog = new Uyeler(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EkleUye;
    private javax.swing.JButton Guncelle;
    private javax.swing.JButton Sil;
    private javax.swing.JTable Users;
    private javax.swing.JLabel count_label;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel kitapadi1;
    private javax.swing.JLabel label;
    private javax.swing.JLabel message5;
    private javax.swing.JTextField name_field;
    private javax.swing.JLabel nametext;
    private javax.swing.JTextField password_field;
    private javax.swing.JLabel ptext;
    private javax.swing.JLabel search;
    private javax.swing.JTextField search_field;
    private javax.swing.JLabel snametext;
    private javax.swing.JTextField surname_field;
    private javax.swing.JLabel unametext;
    private javax.swing.JTextField username_field;
    // End of variables declaration//GEN-END:variables


}
