
package Forms;

import Class.UyeGiris;
import Class.VeriProje;


public class UyeGirisi extends javax.swing.JFrame {

 


    public UyeGirisi() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        message = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        id_field = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        password_field = new javax.swing.JPasswordField();
        GirisYap = new javax.swing.JButton();
        GeriDon = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        message.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        message.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(message);
        message.setBounds(330, 400, 140, 70);

        jLabel1.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(65, 101, 114));
        jLabel1.setText("Şifre");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(180, 210, 140, 70);

        id_field.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        id_field.setForeground(new java.awt.Color(65, 101, 114));
        id_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_fieldActionPerformed(evt);
            }
        });
        jPanel1.add(id_field);
        id_field.setBounds(280, 170, 240, 30);

        jLabel2.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(65, 101, 114));
        jLabel2.setText("Kullanıcı Adı");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(110, 150, 140, 70);

        password_field.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        password_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(password_field);
        password_field.setBounds(280, 230, 240, 30);

        GirisYap.setBackground(new java.awt.Color(168, 194, 206));
        GirisYap.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        GirisYap.setForeground(new java.awt.Color(65, 101, 114));
        GirisYap.setText("Giriş Yap");
        GirisYap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GirisYapActionPerformed(evt);
            }
        });
        jPanel1.add(GirisYap);
        GirisYap.setBounds(310, 290, 180, 50);

        GeriDon.setBackground(new java.awt.Color(168, 194, 206));
        GeriDon.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        GeriDon.setForeground(new java.awt.Color(65, 101, 114));
        GeriDon.setText("Geri Dön");
        GeriDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GeriDonActionPerformed(evt);
            }
        });
        jPanel1.add(GeriDon);
        GeriDon.setBounds(310, 360, 180, 50);

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\üyeeeeeeeeee.png")); // NOI18N
        jPanel1.add(jLabel3);
        jLabel3.setBounds(0, 0, 610, 590);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 605, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    VeriProje vp = new VeriProje();
    UyeGiris uyegiris = new UyeGiris();
    private void GeriDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GeriDonActionPerformed
        Anasayfa anasayfa = new Anasayfa();
        anasayfa.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_GeriDonActionPerformed

    private void id_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_id_fieldActionPerformed

    private void GirisYapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GirisYapActionPerformed
       message.setText("");
        String username = id_field.getText();
        String userpassword = new String(password_field.getPassword());
        boolean result = uyegiris.UyeGirisi(username, userpassword);
        if (result == true) {
            UyeAnasayfa uye = new UyeAnasayfa(this, true);
            this.setVisible(false);
            uye.setVisible(true);
            System.exit(0);
        } else {
            message.setText("Hatalı Giriş");
        }
    }//GEN-LAST:event_GirisYapActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UyeGirisi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UyeGirisi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UyeGirisi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UyeGirisi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UyeGirisi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton GeriDon;
    private javax.swing.JButton GirisYap;
    private javax.swing.JTextField id_field;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel message;
    private javax.swing.JPasswordField password_field;
    // End of variables declaration//GEN-END:variables
}
