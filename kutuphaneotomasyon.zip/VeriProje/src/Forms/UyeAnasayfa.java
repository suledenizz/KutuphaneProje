
package Forms;

import Class.VeriProje;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class UyeAnasayfa extends javax.swing.JDialog {

    DefaultTableModel model1;
    

    public UyeAnasayfa(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        Connect();
        model1 = (DefaultTableModel) jTable1.getModel();
        book();
        IssueBook_load();
    }
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    
    public void Connect(){
     try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
            System.out.println("Veritabanına bağlandı");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmadı...");
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı sağlanmadı");
        }
    }
    
    public class BookItem {

        int id;
        String name;

        public BookItem(int id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }
    
    public void book() {
        try {
            pst = con.prepareStatement("select * from BOOKSS");
            rs = pst.executeQuery();
            bookcombo.removeAllItems();
            while (rs.next()) {
                bookcombo.addItem(new BookItem(rs.getInt(1), rs.getString(2)));
            }

        } catch (SQLException ex) {
            Logger.getLogger(YetkiliAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        public void IssueBook_load() {
        int c;
        try {

            pst = con.prepareStatement("select l.ID, u.name, b.book_name,l.issuedate, l.returndate from LENDBOOK l JOIN USERSS u ON l.memberid =u.ID JOIN BOOKSS b ON l.bookid = b.ID ");
            rs = pst.executeQuery();
            ResultSetMetaData rsd = (ResultSetMetaData) rs.getMetaData();
            c = rsd.getColumnCount();
            DefaultTableModel d = (DefaultTableModel) jTable1.getModel();
            d.setRowCount(0);

            while (rs.next()) {
                Vector v2 = new Vector();
                for (int i = 1; i <= c; i++) {
                    v2.add(rs.getString("ID"));
                    v2.add(rs.getString("name"));
                    v2.add(rs.getString("book_name"));
                    v2.add(rs.getString("issuedate"));
                    v2.add(rs.getString("returndate"));
                }
                d.addRow(v2);

            }

        } catch (SQLException ex) {
            Logger.getLogger(UyeAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        name_field = new javax.swing.JTextField();
        id_field = new javax.swing.JTextField();
        bookcombo = new javax.swing.JComboBox();
        takebook = new com.toedter.calendar.JDateChooser();
        returnbook = new com.toedter.calendar.JDateChooser();
        lendbook = new javax.swing.JButton();
        return_bookk = new javax.swing.JButton();
        Kitaplarım = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        name_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        name_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(name_field);
        name_field.setBounds(260, 210, 230, 30);

        id_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        id_field.setForeground(new java.awt.Color(65, 101, 114));
        id_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                id_fieldKeyPressed(evt);
            }
        });
        jPanel1.add(id_field);
        id_field.setBounds(260, 150, 230, 30);

        bookcombo.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        bookcombo.setForeground(new java.awt.Color(65, 101, 114));
        bookcombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookcomboActionPerformed(evt);
            }
        });
        jPanel1.add(bookcombo);
        bookcombo.setBounds(260, 270, 230, 30);

        takebook.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(takebook);
        takebook.setBounds(260, 330, 230, 30);

        returnbook.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(returnbook);
        returnbook.setBounds(260, 390, 230, 30);

        lendbook.setBackground(new java.awt.Color(168, 194, 206));
        lendbook.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        lendbook.setForeground(new java.awt.Color(65, 101, 114));
        lendbook.setText("Kitabı Ödünç Al");
        lendbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lendbookActionPerformed(evt);
            }
        });
        jPanel1.add(lendbook);
        lendbook.setBounds(280, 460, 200, 40);

        return_bookk.setBackground(new java.awt.Color(168, 194, 206));
        return_bookk.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        return_bookk.setForeground(new java.awt.Color(65, 101, 114));
        return_bookk.setText("Kitabı Geri Ver");
        return_bookk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                return_bookkActionPerformed(evt);
            }
        });
        jPanel1.add(return_bookk);
        return_bookk.setBounds(560, 500, 200, 40);

        Kitaplarım.setBackground(new java.awt.Color(168, 194, 206));
        Kitaplarım.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Kitaplarım.setForeground(new java.awt.Color(65, 101, 114));
        Kitaplarım.setText("Kitaplarım");
        Kitaplarım.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KitaplarımActionPerformed(evt);
            }
        });
        jPanel1.add(Kitaplarım);
        Kitaplarım.setBounds(840, 500, 200, 40);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(65, 101, 114));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Uyenin Adı", "Kitap Adı", "Alış Tarihi", "Veriş Tarihi"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(530, 150, 530, 340);

        jLabel6.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(65, 101, 114));
        jLabel6.setText("Veriş Tarihi");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(140, 370, 140, 70);

        jLabel5.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(65, 101, 114));
        jLabel5.setText("Alış Tarihi");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(150, 310, 140, 70);

        jLabel2.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(65, 101, 114));
        jLabel2.setText("Üye ID");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(180, 130, 140, 70);

        jLabel3.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(65, 101, 114));
        jLabel3.setText("Üye Adı");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(170, 190, 140, 70);

        jLabel4.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(65, 101, 114));
        jLabel4.setText("Kitap Seç");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(160, 250, 140, 70);

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\ssssssssssssssssssssssssssssssssssssssssssssss.png")); // NOI18N
        jPanel1.add(jLabel7);
        jLabel7.setBounds(0, 0, 1150, 790);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1141, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 792, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lendbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lendbookActionPerformed
        String mid = id_field.getText();
        UyeAnasayfa.BookItem bitem = (UyeAnasayfa.BookItem) bookcombo.getSelectedItem();
        SimpleDateFormat date_format = new SimpleDateFormat("dd-MM-YYYY");
        String issuedate = date_format.format(takebook.getDate());
        SimpleDateFormat date_format1 = new SimpleDateFormat("dd-MM-YYYY");
        String returndate = date_format1.format(returnbook.getDate());
        try {
            pst = con.prepareStatement("insert into LENDBOOK(memberid,bookid,issuedate,returndate)values(?,?,?,?)");
            pst.setString(1, mid);
            pst.setInt(2, bitem.id);
            pst.setString(3, issuedate);
            pst.setString(4, returndate);
            int k = pst.executeUpdate();
            if (k == 1) {
                JOptionPane.showMessageDialog(this, "Kitap Alındı.");
                id_field.setText("");
                name_field.setText("");
                bookcombo.setSelectedIndex(-1);
                DefaultTableModel imodel = (DefaultTableModel) jTable1.getModel();
                imodel.addRow(new Object[]{issuedate});
                DefaultTableModel rmodel = (DefaultTableModel) jTable1.getModel();
                rmodel.addRow(new Object[]{returndate});
                takebook.setDate(null);
                returnbook.setDate(null);
                id_field.requestFocus();
                IssueBook_load();
            } else {
                JOptionPane.showMessageDialog(this, "HATA");
            }

        } catch (SQLException ex) {
            Logger.getLogger(UyeAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_lendbookActionPerformed

    private void id_fieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_id_fieldKeyPressed
                if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            String mid = id_field.getText();
            try {
                pst = con.prepareStatement("select * from USERSS where id=?");
                pst.setString(1, mid);
                if (rs.next() == false) {
                    JOptionPane.showMessageDialog(this, "Üye bulunamadı");

                } else {
                    String mname = rs.getString("name");
                    id_field.setText(mname.trim());

                }

            } catch (SQLException ex) {
                Logger.getLogger(UyeAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }//GEN-LAST:event_id_fieldKeyPressed

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked
        DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
        int selectIndex = jTable1.getSelectedRow();
        id_field.setText(d1.getValueAt(selectIndex, 0).toString());
        name_field.setText(d1.getValueAt(selectIndex, 1).toString());
        String comboBook = d1.getValueAt(selectIndex, 2).toString();
        for (int i = 0; i < bookcombo.getItemCount(); i++) {
            if (bookcombo.getItemAt(i).toString().equalsIgnoreCase((comboBook))) {
                bookcombo.setSelectedIndex(i);
            }
        }
        try {
            Date bdate = new SimpleDateFormat("dd-MM-YYYY").parse((String) d1.getValueAt(selectIndex, 3));;

            takebook.setDate(bdate);
        } catch (ParseException ex) {
            Logger.getLogger(UyeAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            Date rdate = new SimpleDateFormat("dd-MM-YYYY").parse((String) d1.getValueAt(selectIndex, 4));;
            returnbook.setDate(rdate);
        } catch (ParseException ex) {
            Logger.getLogger(UyeAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
        }
        lendbook.setEnabled(false);
    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void return_bookkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_return_bookkActionPerformed
        DefaultTableModel d1 = (DefaultTableModel) jTable1.getModel();
        int selectIndex = jTable1.getSelectedRow();
        int id = Integer.parseInt(d1.getValueAt(selectIndex, 0).toString());

        try {
            pst = con.prepareStatement("delete from lendbook where id = ?");
            pst.setInt(1, id);
            int k = pst.executeUpdate();
            if (k == 1) {
                JOptionPane.showMessageDialog(this, "Kitap Geri Verildi");
                id_field.setText("");
                name_field.setText("");
                bookcombo.setSelectedIndex(-1);
                id_field.requestFocus();
                IssueBook_load();
                lendbook.setEnabled(true);

            } else {

                JOptionPane.showMessageDialog(this, "Hata");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UyeAnasayfa.class.getName()).log(Level.SEVERE, null, ex);
        }    }//GEN-LAST:event_return_bookkActionPerformed

    private void bookcomboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookcomboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bookcomboActionPerformed

    private void KitaplarımActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KitaplarımActionPerformed
           BenimKitaplarım kitap = new BenimKitaplarım();
           kitap.setVisible(true);
           this.dispose();
    }//GEN-LAST:event_KitaplarımActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UyeAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UyeAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UyeAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UyeAnasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UyeAnasayfa dialog = new UyeAnasayfa(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Kitaplarım;
    private javax.swing.JComboBox bookcombo;
    private javax.swing.JTextField id_field;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton lendbook;
    private javax.swing.JTextField name_field;
    private javax.swing.JButton return_bookk;
    private com.toedter.calendar.JDateChooser returnbook;
    private com.toedter.calendar.JDateChooser takebook;
    // End of variables declaration//GEN-END:variables
}
