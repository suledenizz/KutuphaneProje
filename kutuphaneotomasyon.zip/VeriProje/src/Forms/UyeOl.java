
package Forms;

import Class.VeriProje;


public class UyeOl extends javax.swing.JFrame {

    public UyeOl() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        message = new javax.swing.JLabel();
        name_field = new javax.swing.JTextField();
        sname_field = new javax.swing.JTextField();
        password_field = new javax.swing.JPasswordField();
        username_field = new javax.swing.JTextField();
        UyeOl = new javax.swing.JButton();
        GeriDon = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(65, 101, 114));
        jLabel2.setText("Kullanıcı Adı");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(80, 180, 140, 70);

        jLabel3.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(65, 101, 114));
        jLabel3.setText("Adınız");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(140, 80, 140, 70);

        jLabel4.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(65, 101, 114));
        jLabel4.setText("Soyadınız");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(110, 130, 140, 70);

        jLabel5.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(65, 101, 114));
        jLabel5.setText("Şifre");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(150, 230, 140, 70);

        message.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        message.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(message);
        message.setBounds(240, 380, 300, 70);

        name_field.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        name_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(name_field);
        name_field.setBounds(240, 100, 240, 30);

        sname_field.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        sname_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(sname_field);
        sname_field.setBounds(240, 150, 240, 30);

        password_field.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        password_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(password_field);
        password_field.setBounds(240, 260, 240, 30);

        username_field.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        username_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(username_field);
        username_field.setBounds(240, 200, 240, 30);

        UyeOl.setBackground(new java.awt.Color(168, 194, 206));
        UyeOl.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        UyeOl.setForeground(new java.awt.Color(65, 101, 114));
        UyeOl.setText("Üye Ol");
        UyeOl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UyeOlActionPerformed(evt);
            }
        });
        jPanel1.add(UyeOl);
        UyeOl.setBounds(260, 310, 190, 30);

        GeriDon.setBackground(new java.awt.Color(168, 194, 206));
        GeriDon.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        GeriDon.setForeground(new java.awt.Color(65, 101, 114));
        GeriDon.setText("Geri Dön");
        GeriDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GeriDonActionPerformed(evt);
            }
        });
        jPanel1.add(GeriDon);
        GeriDon.setBounds(260, 350, 190, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\Adsız.png")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -10, 840, 600);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 636, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 587, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
       VeriProje vp2 = new VeriProje();
    private void UyeOlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UyeOlActionPerformed
        String name = name_field.getText();
        String surname = sname_field.getText();
        String username = username_field.getText();
        String userpassword = password_field.getText();
        /*Burada kullanıcı eğer herhangi bir kutuyu boş bırakırsa
        program hata veriyor ve kayıt olma işlemi gerçekleşmiyor*/
        if(!(name.isEmpty()||surname.isEmpty()||username.isEmpty()||userpassword.isEmpty())){
        vp2.userAdd(name, surname, username, userpassword);
        message.setText("Kayıt İşleminiz Gerçekleşti!");
        }
        else{
        message.setText("Kayıt İşleminiz Gerçekleşemedi!");
        }
    }//GEN-LAST:event_UyeOlActionPerformed

    private void GeriDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GeriDonActionPerformed
        Anasayfa anasayfa = new Anasayfa();
        anasayfa.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_GeriDonActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UyeOl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UyeOl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UyeOl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UyeOl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UyeOl().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton GeriDon;
    private javax.swing.JButton UyeOl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel message;
    private javax.swing.JTextField name_field;
    private javax.swing.JPasswordField password_field;
    private javax.swing.JTextField sname_field;
    private javax.swing.JTextField username_field;
    // End of variables declaration//GEN-END:variables
}
