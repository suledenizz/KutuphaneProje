
package Forms;


public class Anasayfa extends javax.swing.JFrame {

    public Anasayfa() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        KitapOnerisi = new javax.swing.JButton();
        UyeGirisi = new javax.swing.JButton();
        UyeOl = new javax.swing.JButton();
        YetkiliGiris = new javax.swing.JButton();
        KitapYorumlari = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        KitapOnerisi.setBackground(new java.awt.Color(168, 194, 206));
        KitapOnerisi.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        KitapOnerisi.setForeground(new java.awt.Color(65, 101, 114));
        KitapOnerisi.setText("Kitap Önerisi");
        KitapOnerisi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KitapOnerisiActionPerformed(evt);
            }
        });
        jPanel1.add(KitapOnerisi);
        KitapOnerisi.setBounds(220, 340, 200, 60);

        UyeGirisi.setBackground(new java.awt.Color(168, 194, 206));
        UyeGirisi.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        UyeGirisi.setForeground(new java.awt.Color(65, 101, 114));
        UyeGirisi.setText("Üye Girişi");
        UyeGirisi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UyeGirisiActionPerformed(evt);
            }
        });
        jPanel1.add(UyeGirisi);
        UyeGirisi.setBounds(90, 140, 200, 60);

        UyeOl.setBackground(new java.awt.Color(168, 194, 206));
        UyeOl.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        UyeOl.setForeground(new java.awt.Color(65, 101, 114));
        UyeOl.setText("Üye Ol");
        UyeOl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UyeOlActionPerformed(evt);
            }
        });
        jPanel1.add(UyeOl);
        UyeOl.setBounds(90, 240, 200, 60);

        YetkiliGiris.setBackground(new java.awt.Color(168, 194, 206));
        YetkiliGiris.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        YetkiliGiris.setForeground(new java.awt.Color(65, 101, 114));
        YetkiliGiris.setText("Yetkili Giriş");
        YetkiliGiris.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                YetkiliGirisActionPerformed(evt);
            }
        });
        jPanel1.add(YetkiliGiris);
        YetkiliGiris.setBounds(340, 140, 200, 60);

        KitapYorumlari.setBackground(new java.awt.Color(168, 194, 206));
        KitapYorumlari.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        KitapYorumlari.setForeground(new java.awt.Color(65, 101, 114));
        KitapYorumlari.setText("Kitap Yorumları");
        KitapYorumlari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KitapYorumlariActionPerformed(evt);
            }
        });
        jPanel1.add(KitapYorumlari);
        KitapYorumlari.setBounds(340, 240, 200, 60);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\ddddddddddddddddddddddddddd.png")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 610, 580);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 605, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 581, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void KitapYorumlariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KitapYorumlariActionPerformed
        KitapYorum ky = new KitapYorum(this, true);
        setVisible(false);
        ky.setVisible(true);
        System.exit(0);
    }//GEN-LAST:event_KitapYorumlariActionPerformed

    private void UyeGirisiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UyeGirisiActionPerformed
        UyeGirisi uyegirisi = new UyeGirisi();
        uyegirisi.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_UyeGirisiActionPerformed

    private void YetkiliGirisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_YetkiliGirisActionPerformed
        YetkiliGiris yetkiligiris = new YetkiliGiris();
        yetkiligiris.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_YetkiliGirisActionPerformed

    private void UyeOlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UyeOlActionPerformed
        UyeOl uyeol = new UyeOl();
        uyeol.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_UyeOlActionPerformed

    private void KitapOnerisiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KitapOnerisiActionPerformed
        KitapOneri ko = new KitapOneri(this, true);
        setVisible(false);
        ko.setVisible(true);
        System.exit(0);
    }//GEN-LAST:event_KitapOnerisiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Anasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Anasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Anasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Anasayfa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Anasayfa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton KitapOnerisi;
    private javax.swing.JButton KitapYorumlari;
    private javax.swing.JButton UyeGirisi;
    private javax.swing.JButton UyeOl;
    private javax.swing.JButton YetkiliGiris;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
