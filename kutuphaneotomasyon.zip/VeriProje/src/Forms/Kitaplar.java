
package Forms;

import Class.Book;
import Class.VeriProje;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class Kitaplar extends javax.swing.JDialog {
    
    DefaultTableModel model1;
    VeriProje vp1 = new VeriProje();
    
    public Kitaplar(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model1 = (DefaultTableModel)(Books.getModel());
        bookView();
        bookNumber();
    }

    Kitaplar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    
    public void bookNumber(){
    count_label.setText("0");
    int i = vp1.bookCount();
    String ii=String.valueOf(i);
    count_label.setText(ii);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        scroll = new javax.swing.JScrollPane();
        Books = new javax.swing.JTable();
        label = new javax.swing.JLabel();
        search = new javax.swing.JLabel();
        writer_field = new javax.swing.JTextField();
        name_field = new javax.swing.JTextField();
        page_field = new javax.swing.JTextField();
        genre_field = new javax.swing.JTextField();
        publisher_field = new javax.swing.JTextField();
        yazaradi = new javax.swing.JLabel();
        kitapadi1 = new javax.swing.JLabel();
        sayfa = new javax.swing.JLabel();
        turu = new javax.swing.JLabel();
        yayinevi = new javax.swing.JLabel();
        search_field = new javax.swing.JTextField();
        KitapEkle = new javax.swing.JButton();
        Güncelle = new javax.swing.JButton();
        Sil = new javax.swing.JButton();
        count_label = new javax.swing.JLabel();
        bookadd = new javax.swing.JLabel();
        message4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        scroll.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        scroll.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                scrollMouseClicked(evt);
            }
        });

        Books.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        Books.setForeground(new java.awt.Color(65, 101, 114));
        Books.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "book_name", "writer", "book_page", "genre", "publisher"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        scroll.setViewportView(Books);

        jPanel1.add(scroll);
        scroll.setBounds(480, 210, 620, 290);

        label.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        label.setForeground(new java.awt.Color(65, 101, 114));
        label.setText("Kütüphanedeki Kitap Sayısı");
        jPanel1.add(label);
        label.setBounds(670, 560, 360, 30);

        search.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        search.setForeground(new java.awt.Color(65, 101, 114));
        search.setText("Arama Yapılacak Kelime");
        jPanel1.add(search);
        search.setBounds(710, 120, 360, 30);

        writer_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        writer_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(writer_field);
        writer_field.setBounds(250, 260, 217, 30);

        name_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        name_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(name_field);
        name_field.setBounds(250, 210, 217, 30);

        page_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        page_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(page_field);
        page_field.setBounds(250, 310, 217, 30);

        genre_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        genre_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(genre_field);
        genre_field.setBounds(250, 370, 217, 30);

        publisher_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        publisher_field.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(publisher_field);
        publisher_field.setBounds(250, 420, 217, 30);

        yazaradi.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        yazaradi.setForeground(new java.awt.Color(65, 101, 114));
        yazaradi.setText("Yazar Adı");
        jPanel1.add(yazaradi);
        yazaradi.setBounds(150, 260, 140, 30);

        kitapadi1.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        kitapadi1.setForeground(new java.awt.Color(65, 101, 114));
        kitapadi1.setText("Kitap Adı");
        jPanel1.add(kitapadi1);
        kitapadi1.setBounds(150, 210, 140, 30);

        sayfa.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        sayfa.setForeground(new java.awt.Color(65, 101, 114));
        sayfa.setText("Sayfa Sayısı");
        jPanel1.add(sayfa);
        sayfa.setBounds(130, 310, 150, 30);

        turu.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        turu.setForeground(new java.awt.Color(65, 101, 114));
        turu.setText("Türü");
        jPanel1.add(turu);
        turu.setBounds(190, 370, 160, 30);

        yayinevi.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        yayinevi.setForeground(new java.awt.Color(65, 101, 114));
        yayinevi.setText("Yayınevi");
        jPanel1.add(yayinevi);
        yayinevi.setBounds(160, 420, 130, 30);

        search_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        search_field.setForeground(new java.awt.Color(65, 101, 114));
        search_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_fieldActionPerformed(evt);
            }
        });
        search_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_fieldKeyReleased(evt);
            }
        });
        jPanel1.add(search_field);
        search_field.setBounds(480, 160, 620, 30);

        KitapEkle.setBackground(new java.awt.Color(168, 194, 206));
        KitapEkle.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        KitapEkle.setForeground(new java.awt.Color(65, 101, 114));
        KitapEkle.setText("Kitap Ekle");
        KitapEkle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                KitapEkleActionPerformed(evt);
            }
        });
        jPanel1.add(KitapEkle);
        KitapEkle.setBounds(260, 470, 180, 40);

        Güncelle.setBackground(new java.awt.Color(168, 194, 206));
        Güncelle.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Güncelle.setForeground(new java.awt.Color(65, 101, 114));
        Güncelle.setText("Güncelle");
        Güncelle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GüncelleActionPerformed(evt);
            }
        });
        jPanel1.add(Güncelle);
        Güncelle.setBounds(590, 510, 180, 40);

        Sil.setBackground(new java.awt.Color(168, 194, 206));
        Sil.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        Sil.setForeground(new java.awt.Color(65, 101, 114));
        Sil.setText("Sil");
        Sil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SilActionPerformed(evt);
            }
        });
        jPanel1.add(Sil);
        Sil.setBounds(860, 510, 180, 40);

        count_label.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        count_label.setForeground(new java.awt.Color(65, 101, 114));
        count_label.setText("10");
        jPanel1.add(count_label);
        count_label.setBounds(790, 570, 70, 80);

        bookadd.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        bookadd.setForeground(new java.awt.Color(65, 101, 114));
        bookadd.setText("Kitap Ekle");
        jPanel1.add(bookadd);
        bookadd.setBounds(290, 150, 120, 40);

        message4.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        message4.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(message4);
        message4.setBounds(270, 530, 270, 100);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\vfvfvfffff.png")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -30, 1250, 890);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1209, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 839, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void filter(String query){
    TableRowSorter <DefaultTableModel> trs = new TableRowSorter <DefaultTableModel>(model1);
    Books.setRowSorter(trs);
    trs.setRowFilter(RowFilter.regexFilter(query));
    }
 
    
    private void scrollMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_scrollMouseClicked
        int selectedrow = Books.getSelectedRow();
        name_field.setText(model1.getValueAt(selectedrow,1).toString());
        writer_field.setText(model1.getValueAt(selectedrow,2).toString());
        page_field.setText(model1.getValueAt(selectedrow,3).toString());
        genre_field.setText(model1.getValueAt(selectedrow,4).toString());
        publisher_field.setText(model1.getValueAt(selectedrow,5).toString());
    }//GEN-LAST:event_scrollMouseClicked

    private void search_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_search_fieldActionPerformed

    private void search_fieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_fieldKeyReleased
        String query = search_field.getText();
        filter(query);

    }//GEN-LAST:event_search_fieldKeyReleased

    private void KitapEkleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_KitapEkleActionPerformed
       message4.setText("");
        String name = name_field.getText();
        String writer = writer_field.getText();
        String page = page_field.getText();
        String genre = genre_field.getText();
        String publisher = publisher_field.getText();
        if(!(name.isEmpty()||writer.isEmpty()||page.isEmpty()||genre.isEmpty()||publisher.isEmpty())){
        vp1.bookAdd(name, writer, page, genre, publisher);
        bookView();
        message4.setText("Kitap Eklendi");
        }
        else{
        message4.setText("Kitap Eklenemedi!");
        }
    }//GEN-LAST:event_KitapEkleActionPerformed

    private void GüncelleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GüncelleActionPerformed
        String name = name_field.getText();
        String writer = writer_field.getText();
        String page = page_field.getText();
        String genre = genre_field.getText();
        String publisher = publisher_field.getText();
        
        int selectedrow = Books.getSelectedRow();
        /* Burada eğer yetkili güncellemek istediği kitaba basmadan güncelle butonuna basarsa
        program ekrana mesaj yazdırıyor
        */
        if(selectedrow == -1){
            if(model1.getRowCount()==0){
                message4.setText("");
            }
            else{
                message4.setText("Güncellenecek Kitap Seçiniz");
            }
        }
        else{
        int id =(int) model1.getValueAt(selectedrow, 0);
        vp1.bookUpdate(id,name,writer,page,genre,publisher);
        bookView();
        message4.setText("Kitap Bilgileri Güncellendi");
        }
    }//GEN-LAST:event_GüncelleActionPerformed

    private void SilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SilActionPerformed
               message4.setText("");
        int selectedrow = Books.getSelectedRow();
        
        if(selectedrow == -1){
            if(model1.getRowCount()==0){
                message4.setText("");
            }
            else{
                message4.setText("Silinecek Kitabı Seçiniz");
            }
        }
        else{
        int id =(int) model1.getValueAt(selectedrow, 0);
        vp1.bookDelete(id);
        bookView();
        message4.setText("Kitap Silindi");
        }
    }//GEN-LAST:event_SilActionPerformed

        public void bookView(){
        model1.setRowCount(0); //her açılışta güncelleyip getirecek
        ArrayList<Book> books = new ArrayList<Book> ();
        books = vp1.BookCome();
        if(books!=null){
            for(Book b : books){
                Object [] add = {b.getId(),b.getBook_name(),b.getWriter(), b.getBook_page(), b.getGenre(),b.getPublisher()};
                model1.addRow(add);
            }
        }
    }
        
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Kitaplar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Kitaplar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Kitaplar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Kitaplar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Kitaplar dialog = new Kitaplar(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Books;
    private javax.swing.JButton Güncelle;
    private javax.swing.JButton KitapEkle;
    private javax.swing.JButton Sil;
    private javax.swing.JLabel bookadd;
    private javax.swing.JLabel count_label;
    private javax.swing.JTextField genre_field;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel kitapadi1;
    private javax.swing.JLabel label;
    private javax.swing.JLabel message4;
    private javax.swing.JTextField name_field;
    private javax.swing.JTextField page_field;
    private javax.swing.JTextField publisher_field;
    private javax.swing.JLabel sayfa;
    private javax.swing.JScrollPane scroll;
    private javax.swing.JLabel search;
    private javax.swing.JTextField search_field;
    private javax.swing.JLabel turu;
    private javax.swing.JTextField writer_field;
    private javax.swing.JLabel yayinevi;
    private javax.swing.JLabel yazaradi;
    // End of variables declaration//GEN-END:variables
}
