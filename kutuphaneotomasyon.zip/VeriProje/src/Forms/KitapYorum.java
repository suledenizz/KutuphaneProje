
package Forms;

import Class.Comment;
import Class.VeriProje;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class KitapYorum extends javax.swing.JDialog {
    
    DefaultTableModel model1;
    VeriProje vp3 = new VeriProje();

    public KitapYorum(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model1 = (DefaultTableModel)(comments.getModel());
        commentView();
    }


    
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        geridon = new javax.swing.JButton();
        commentnofield = new javax.swing.JTextField();
        bookid_field = new javax.swing.JTextField();
        memberid_field = new javax.swing.JTextField();
        comment_field = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        comments = new javax.swing.JTable();
        comment_add = new javax.swing.JButton();
        message4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1164, 646));

        jPanel1.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(65, 101, 114));
        jLabel5.setText("Yorum No");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(140, 150, 120, 20);

        jLabel3.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(65, 101, 114));
        jLabel3.setText("Book ID");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(160, 170, 140, 70);

        jLabel2.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(65, 101, 114));
        jLabel2.setText("Üye ID");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(170, 230, 140, 70);

        jLabel4.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(65, 101, 114));
        jLabel4.setText("Kitap Yorumu");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(110, 300, 140, 70);

        geridon.setBackground(new java.awt.Color(168, 194, 206));
        geridon.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        geridon.setForeground(new java.awt.Color(65, 101, 114));
        geridon.setText("Geri Dön");
        geridon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                geridonActionPerformed(evt);
            }
        });
        jPanel1.add(geridon);
        geridon.setBounds(690, 490, 200, 40);

        commentnofield.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        commentnofield.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(commentnofield);
        commentnofield.setBounds(260, 140, 230, 30);

        bookid_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        bookid_field.setForeground(new java.awt.Color(65, 101, 114));
        bookid_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                bookid_fieldKeyPressed(evt);
            }
        });
        jPanel1.add(bookid_field);
        bookid_field.setBounds(260, 190, 230, 30);

        memberid_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        memberid_field.setForeground(new java.awt.Color(65, 101, 114));
        memberid_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                memberid_fieldKeyPressed(evt);
            }
        });
        jPanel1.add(memberid_field);
        memberid_field.setBounds(260, 250, 230, 30);

        comment_field.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        comment_field.setForeground(new java.awt.Color(65, 101, 114));
        comment_field.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                comment_fieldKeyPressed(evt);
            }
        });
        jPanel1.add(comment_field);
        comment_field.setBounds(260, 310, 230, 140);

        jScrollPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jScrollPane1MouseClicked(evt);
            }
        });

        comments.setFont(new java.awt.Font("Georgia", 0, 12)); // NOI18N
        comments.setForeground(new java.awt.Color(65, 101, 114));
        comments.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "commentno", "book_id", "user_id", "book_comment"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(comments);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(520, 140, 540, 310);

        comment_add.setBackground(new java.awt.Color(168, 194, 206));
        comment_add.setFont(new java.awt.Font("Georgia", 0, 18)); // NOI18N
        comment_add.setForeground(new java.awt.Color(65, 101, 114));
        comment_add.setText("Yorum Ekle");
        comment_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comment_addActionPerformed(evt);
            }
        });
        jPanel1.add(comment_add);
        comment_add.setBounds(270, 490, 200, 40);

        message4.setFont(new java.awt.Font("Georgia", 0, 20)); // NOI18N
        message4.setForeground(new java.awt.Color(65, 101, 114));
        jPanel1.add(message4);
        message4.setBounds(190, 550, 350, 100);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Asus23Jun2020\\Desktop\\şşşşşşşşşşşşş\\yorum.png")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, -50, 1170, 890);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1164, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 794, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bookid_fieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bookid_fieldKeyPressed

    }//GEN-LAST:event_bookid_fieldKeyPressed

    private void memberid_fieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_memberid_fieldKeyPressed

    }//GEN-LAST:event_memberid_fieldKeyPressed

    private void comment_fieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_comment_fieldKeyPressed

    }//GEN-LAST:event_comment_fieldKeyPressed

    private void comment_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comment_addActionPerformed
        message4.setText("");
        String book_id = bookid_field.getText();
        String user_id = memberid_field.getText();
        String book_comment = comment_field.getText();
        if(!(book_id.isEmpty()||user_id.isEmpty()||book_comment.isEmpty())){
        vp3.commentAdd(book_id, user_id, book_comment);
        commentView();
        message4.setText("Yorum Eklendi");
        }
        else{
        message4.setText("Yorum Eklenemedi!");
        }
    }//GEN-LAST:event_comment_addActionPerformed

    private void jScrollPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jScrollPane1MouseClicked
         int selectedrow = comments.getSelectedRow();
         commentnofield.setText(model1.getValueAt(selectedrow,0).toString());
        bookid_field.setText(model1.getValueAt(selectedrow,1).toString());
        memberid_field.setText(model1.getValueAt(selectedrow,2).toString());
        comment_field.setText(model1.getValueAt(selectedrow,3).toString());
        
    }//GEN-LAST:event_jScrollPane1MouseClicked

    private void geridonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_geridonActionPerformed
      Anasayfa anasayfa = new Anasayfa();
        anasayfa.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_geridonActionPerformed

    
            public void commentView(){
        model1.setRowCount(0); //her açılışta güncelleyip getirecek
        ArrayList<Comment> comments = new ArrayList<Comment> ();
        comments = vp3.CommentCome();
        if(comments!=null){
            for(Comment c : comments){
                Object [] add = {c.getcommentno(),c.getbook_id(),c.getuser_id(), c.getbook_comment()};
                model1.addRow(add);
            }
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KitapYorum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KitapYorum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KitapYorum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KitapYorum.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                KitapYorum dialog = new KitapYorum(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bookid_field;
    private javax.swing.JButton comment_add;
    private javax.swing.JTextField comment_field;
    private javax.swing.JTextField commentnofield;
    private javax.swing.JTable comments;
    private javax.swing.JButton geridon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField memberid_field;
    private javax.swing.JLabel message4;
    // End of variables declaration//GEN-END:variables
}
