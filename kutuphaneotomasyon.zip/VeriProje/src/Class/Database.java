
package Class;


public class Database {
   public static final String id = "system";
   public static final String password = "1234";
   public static final String host = "localhost";
   public static final String port = "1521";
   public static final String db_name = "XE";
}
