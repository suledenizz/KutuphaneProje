
package Class;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UyeGiris extends VeriProje {
    
        public boolean UyeGirisi(String username, String userpassword) {

        String sorgu = "Select * from USERSS where username =? and userpassword = ?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, username);
            psta.setString(2, userpassword);
            ResultSet rs = psta.executeQuery();
            return rs.next();

        } catch (SQLException ex) {
            Logger.getLogger(UyeGiris.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
}
