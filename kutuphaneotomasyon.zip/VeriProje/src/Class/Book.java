
package Class;


public class Book {
    private int id;
    private String book_name;
    private String writer;
    private String book_page;
    private String genre;
    private String publisher;
    
    public Book (){}

    public Book(int id, String book_name, String writer, String book_page, String genre, String publisher) {
        this.id = id;
        this.book_name = book_name;
        this.writer = writer;
        this.book_page=book_page;
        this.genre = genre;
        this.publisher = publisher;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public String getWriter() {
        return writer;
    }

    public void setWriter(String writer) {
        this.writer = writer;
    }
    public String getBook_page() {
        return book_page;
    }

    public void setBook_page(String book_page) {
        this.book_page = book_page;
    }
    

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    
}
