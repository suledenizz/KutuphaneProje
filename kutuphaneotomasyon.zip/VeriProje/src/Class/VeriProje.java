
package Class;

import Class.Book;
import Class.Database;
import Class.User;
import Class.UyeGiris;
import Forms.KitapOneri;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class VeriProje {
    
    Connection con = null ;
    Statement sta = null ;
    PreparedStatement psta = null ;
    
    
        public int bookCount() {
        int label = 0;
        String sorgu = "SELECT COUNT(*) FROM BOOKSS";
        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);
            rs.next();
            label = rs.getInt(1);

        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return 0;

        }
        return label;
    }
     //Kitapları Silen
     public void bookDelete(int id) {
        String sorgu = "Delete from BOOKSS WHERE id=?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setInt(1, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     //Kitap Güncelleme
     public void bookUpdate(int id, String new_name, String new_writer, String new_page, String new_genre, String new_publisher) {
        String sorgu = "Update BOOKSS SET book_name=?,writer=?,book_page=?,genre=?,publisher=? WHERE id=?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, new_name);
            psta.setString(2, new_writer);
            psta.setString(3, new_page);
            psta.setString(4, new_genre);
            psta.setString(5, new_publisher);
            psta.setInt(6, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     //Kitap ekle
       public void bookAdd(String name, String writer, String page, String genre, String publisher) {

        String sorgu = "Insert into BOOKSS(book_name,writer, book_page, genre, publisher) VALUES (?,?,?,?,?)";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, name);
            psta.setString(2, writer);
            psta.setString(3, page);
            psta.setString(4, genre);
            psta.setString(5, publisher);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
       public ArrayList<Book> BookCome() {
        ArrayList<Book> list = new ArrayList<Book>();
        String sorgu = "Select * from BOOKSS";

        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);

            while (rs.next()) {
                int id = rs.getInt("id");
                String book_name = rs.getString("book_name");
                String writer = rs.getString("writer");
                String book_page = rs.getString("book_page");
                String genre = rs.getString("genre");
                String publisher = rs.getString("publisher");
                list.add(new Book(id, book_name, writer, book_page, genre, publisher));
            }

            return list;
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
       public ArrayList<User> UserCome() {
        ArrayList<User> list = new ArrayList<User>();
        String sorgu = "Select * from USERSS";

        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String surname = rs.getString("surname");
                String username = rs.getString("username");
                String userpassword = rs.getString("userpassword");
                list.add(new User(id, name, surname, username, userpassword));
            }

            return list;
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
       
       
        public ArrayList<Comment> CommentCome() {
        ArrayList<Comment> list = new ArrayList<Comment>();
        String sorgu = "Select * from BOOKSCOMMENTS ";
        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);

            while (rs.next()) {
                int commentno = rs.getInt("commentno");
                String book_id = rs.getString("book_id");
                String user_id = rs.getString("user_id");
                String book_comment = rs.getString("book_comment");
                list.add(new Comment(commentno, book_id, user_id, book_comment));
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
     
        //Üye girişi
            public boolean UyeGirisi(String username, String userpassword) {

        String sorgu = "Select * from USERSS where username =? and userpassword = ?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, username);
            psta.setString(2, userpassword);
            ResultSet rs = psta.executeQuery();
            return rs.next();

        } catch (SQLException ex) {
            Logger.getLogger(UyeGiris.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    //yetkili giriş
        public boolean YetkiliGirisi(String unam, String upassword) {
        String sorgu = "Select * from ADMIN where UNAME = ? and PASSWORD = ?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1,unam);
            psta.setString(2,upassword);
            ResultSet rs = psta.executeQuery();
            return rs.next();

        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public VeriProje() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
            System.out.println("Veritabanına bağlandı");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmadı...");
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı sağlanmadı");
        }
    }

    public static void main(String[] args) {
    VeriProje vp = new VeriProje();

    }
    
     //Kullanıcı ekle
    public void userAdd(String name, String surname, String username, String userpassword) {
        String sorgu1 = "INSERT INTO USERSS(name,surname, username, userpassword) VALUES (?,?,?,?)";
        try {
            psta = con.prepareStatement(sorgu1);
            psta.setString(1, name);
            psta.setString(2, surname);
            psta.setString(3, username);
            psta.setString(4, userpassword);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //Kullanıcı Güncelle
        public void userUpdate(int id, String new_name, String new_surname, String new_username, String new_password) {
        String sorgu = "Update USERSS SET name=?,surname=?,username=?,userpassword=? WHERE id=?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, new_name);
            psta.setString(2, new_surname);
            psta.setString(3, new_username);
            psta.setString(4, new_password);
            psta.setInt(5, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//Kullanıcı Sil
    /*public void userDelete(int id) {
        String sorgu = "Delete from USERSS WHERE id=?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setInt(1, id);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    
    
        public void userDelete(int id) {
       CallableStatement csmt;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
            csmt=con.prepareCall("{CALL UYESIL(?)}");
            csmt.setInt(1, id);
            csmt.execute();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Driver çalışmadı...");
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Bağlantı sağlanmadı");
        }
    }
//Kullanıcı sayma
    
    public int userCount() {
        int label1 = 0;
        String sorgu = "SELECT COUNT(*) FROM USERSS";
        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);
            rs.next();
            label1 = rs.getInt(1);

        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
        return label1;
    }
    
        public void commentAdd(String book_id, String user_id, String book_comment) {
        String sorgu = "Insert into BOOKSCOMMENTS(book_id, user_id, book_comment) VALUES (?,?,?)";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, book_id);
            psta.setString(2, user_id);
            psta.setString(3, book_comment);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        
        public void commentDelete(int commentno) {
        String sorgu = "Delete from BOOKSCOMMENTS WHERE commentno=?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setInt(1, commentno);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
        public void commentUpdate(int commentno, String newbook_id, String newuser_id, String newbook_comment) {
        String sorgu = "Update BOOKSCOMMENTS SET book_id=?,user_id=?,book_comment=? WHERE id=?";
        try {
            psta = con.prepareStatement(sorgu);
            psta.setString(1, newbook_id);
            psta.setString(2, newuser_id);
            psta.setString(3, newbook_comment);
            psta.setInt(4, commentno);
            psta.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
            public ArrayList<Books> GetData(String genre) {
        ArrayList<Books> list = new ArrayList<Books>();
        String sorgu = "Select * from BOOKSS where genre= '"+genre+"'";
        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);
            Books b ;
            while (rs.next()) {
                b = new Books(
                rs.getInt("id"),
                rs.getString("book_name"),
                rs.getString("writer"),
                rs.getString("book_page"),
                rs.getString("genre"),        
                rs.getString("publisher")
                );
                list.add(b);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
        public ArrayList<MyBooks> GetDatauser(int memberid) {
        ArrayList<MyBooks> list = new ArrayList<MyBooks>();
        String sorgu = "Select * from MYBOOKS where memberid= '"+memberid+"'";
        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);
            MyBooks b ;
            while (rs.next()) {
                b = new MyBooks(
                rs.getInt("memberid"),
                rs.getInt("bookid")
                );
                list.add(b);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
        public ArrayList<Comment> MyComments(int user_id) {
        ArrayList<Comment> list = new ArrayList<Comment>();
        String sorgu = "Select * from BOOKSCOMMENTS where user_id= '"+user_id+"'";
        try {
            sta = con.createStatement();
            ResultSet rs = sta.executeQuery(sorgu);

            while (rs.next()) {
                int commentno = rs.getInt("commentno");
                String book_id = rs.getString("book_id");
                String user_idd = rs.getString("user_id");
                String book_comment = rs.getString("book_comment");
                list.add(new Comment(commentno, book_id, user_idd, book_comment));
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(VeriProje.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

}
