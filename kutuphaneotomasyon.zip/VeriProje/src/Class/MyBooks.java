
package Class;

public class MyBooks {
    private int memberid;
    private int bookid;
    
     public int getmemberid() {
        return memberid;
    }

    public void setmemberid(int memberid) {
        this.memberid = memberid;
    }
    public int getbookid() {
        return bookid;
    }

    public void setbookid(int bookid) {
        this.bookid = bookid;
    }
    
    public MyBooks(int memberid, int bookid) {
        this.memberid = memberid;
        this.bookid = bookid;
    }
   
}
