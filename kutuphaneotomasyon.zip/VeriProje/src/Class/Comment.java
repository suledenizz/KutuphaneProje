

package Class;


public class Comment {
    private int commentno;
    private String book_id;
    private String user_id;
    private String book_comment;
    
     public int getcommentno() {
        return commentno;
    }

    public void setcommentno(int commentno) {
        this.commentno = commentno;
    }

    public String getbook_id() {
        return book_id;
    }

    public void setbook_id(String book_id) {
        this.book_id = book_id;
    }

    public String getuser_id() {
        return user_id;
    }

    public void setuser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getbook_comment() {
        return book_comment;
    }

    public void setbook_comment(String book_comment) {
        this.book_comment = book_comment;
    }
        public Comment(int commentno, String book_id, String user_id, String book_comment) {
        this.commentno = commentno;
        this.book_id = book_id;
        this.user_id = user_id;
        this.book_comment = book_comment;

    }

}
